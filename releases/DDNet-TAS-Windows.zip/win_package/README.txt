Instructions in BUILDING.md
