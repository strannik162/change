#ifndef ENGINE_CLIENT_DEMOEDIT_H
#define ENGINE_CLIENT_DEMOEDIT_H

#include <base/types.h>

#include <engine/shared/demo.h>
#include <engine/shared/jobs.h>
#include <engine/shared/snapshot.h>

class IStorage;

class CDemoEdit : public IJob
{
	CSnapshotDelta m_SnapshotDelta;
	CSnapshotDelta m_SnapshotDeltaSixup;
	IStorage *m_pStorage;

	CDemoEditor m_DemoEditor;

	char m_aDemo[IO_MAX_PATH_LENGTH];
	char m_aDst[IO_MAX_PATH_LENGTH];
	int m_StartTick;
	int m_EndTick;
	bool m_Success;

public:
	CDemoEdit(const char *pNetVersion, CSnapshotDelta *pSnapshotDelta, CSnapshotDelta *pSnapshotDeltaSixup, IStorage *pStorage, const char *pDemo, const char *pDst, int StartTick, int EndTick);
	void Run() override;
	char *Destination() { return m_aDst; }
	bool Success() const { return m_Success; }
};
#endif
